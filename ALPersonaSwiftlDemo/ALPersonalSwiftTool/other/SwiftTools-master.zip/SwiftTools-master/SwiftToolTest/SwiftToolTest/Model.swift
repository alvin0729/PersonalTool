//
//  Model.swift
//  SwiftToolTest
//
//  Created by yunna on 2018/4/28.
//  Copyright © 2018年 yunna. All rights reserved.
//

import UIKit
import SwiftyJSON

class groupModel: NSObject {
    var groupName = ""
    var detailArr = NSMutableArray()
    
}


class Model: NSObject {
    var title = ""
    var className = ""
}




































