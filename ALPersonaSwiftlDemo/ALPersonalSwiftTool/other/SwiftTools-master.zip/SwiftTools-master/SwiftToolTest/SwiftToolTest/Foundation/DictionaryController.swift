//
//  DictionaryController.swift
//  SwiftToolTest
//
//  Created by yunna on 2018/5/16.
//  Copyright © 2018年 yunna. All rights reserved.
//

import UIKit

class DictionaryController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    

}
