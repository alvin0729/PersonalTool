//
//  ArrayController.swift
//  SwiftToolTest
//
//  Created by yunna on 2018/5/15.
//  Copyright © 2018年 yunna. All rights reserved.
//

import UIKit

class ArrayController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
 
        let list = ["1","1","2","2"]
        print(list.removedDuplicates())
    
    
    }

    
}
